# OniRoai 0.5.0 — Android ARM64, offline

Bản này nâng cấp giao diện của Tiền Đồn 0.4.0 và đổi tên game thành **OniRoai**.
APK mới là `OniRoai-0.5.0.apk`, versionCode **10**. Giữ package
`vn.minhquan.tiendon` và khóa ký cũ để cài cập nhật.

## Cài trên điện thoại

1. Tải `OniRoai-0.5.0.apk`, mở bằng trình quản lý file, chọn **Cập nhật**.
2. Nếu Android hỏi, cho phép trình quản lý file đang dùng cài APK.
3. Mở **OniRoai**, xoay ngang, đợi màn hình tải rồi bấm **BẮT ĐẦU TRẬN**.
4. Màn hình chính có avatar mới và số bản **0.5.0** phía dưới. Phần thông tin
   ứng dụng của Android cũng phải ghi **0.5.0**.

Tất cả ảnh, model, font và âm thanh có sẵn trong APK. Không cần mạng hoặc tải
thêm gói dữ liệu. Không cần Termux hay cài Godot nếu chỉ muốn chơi.

## Những thay đổi giao diện

- Ô súng/đạn chuyển lên góc **phải trên**. Khung kim loại và ảnh MP5 dùng PNG
  được vẽ mới. Đạn cập nhật theo phát bắn; ảnh súng có chuyển động nhẹ khi bắn.
- **Chạm bất kỳ vị trí nào trong ô súng để nạp đạn.** Đã bỏ nút Nạp đạn riêng
  phía dưới. Thanh tiến trình và thời gian nạp nằm trong ô súng.
- Joystick di chuyển trái dưới và cần bắn phải dưới dùng ảnh vòng kim loại,
  núm nổi có bề mặt và ánh sáng. Núm đi theo ngón, nhấn/nhả có chuyển động.
- Cúi/Nhảy dùng ảnh nút mới, đặt ở giữa dưới. Ngắm, Chạy, Bắn trái và Tạm dừng
  cùng phong cách. Nút Tạm dừng ở **trái trên** để nhường ô súng.
- Bỏ ô chữ giới thiệu/trạng thái trái trên và bỏ la bàn. Ô điểm giữa trên
  dùng khung ảnh mới, hiện điểm, số người còn sống và ván hiện tại.
- Khi ngắm, vẫn nhìn được cảnh vật ở hai bên. Đã bỏ mặt nạ đen kín màn hình,
  mở đường nhìn qua lòng ống kính của model 3D; tâm ngắm nhỏ nằm ở giữa.
- Khi giữ bắn, súng nâng về gần giữa màn hình rồi hạ xuống sau khi thả cò.
  Độ giật tác động lên súng/camera. Đầu nòng dùng ảnh chớp nhỏ và khói nhẹ,
  không dùng ô vuông sáng. Mỗi ván mới đặt lại súng về tư thế hạ thấp.
- Màn hình tải có tranh nền riêng, avatar OniRoai, chuyển động chậm của ảnh,
  vòng chờ quay, tiến trình nạp tài nguyên và chuyển cảnh mờ dần.
- Avatar/logo mới cũng là biểu tượng ứng dụng Android.

Bộ ảnh gốc, vùng atlas và toàn bộ mô tả tạo ảnh nằm trong `assets/oniroai`.
Đây là ảnh raster tạo bằng công cụ tạo ảnh; code xử lý số liệu, cảm ứng và
chuyển động. Tranh màn hình tải là minh họa, không phải ảnh gameplay.

## Cách chơi và điều khiển

Bạn một đội, **4 NPC cầm súng** ở đội kia. Một phát trúng là bị loại ở cả hai
đội. Hạ cả 4 NPC để thắng ván và được 1 điểm; bạn bị hạ thì đội máy được 1 điểm.
Đội chạm **4 điểm** trước thắng trận. Mỗi ván khôi phục 30 viên trong băng,
180 viên dự trữ và đúng 4 NPC; điểm trận được giữ. Không có hồi sinh giữa ván.

| Vị trí | Thao tác |
| --- | --- |
| Cần trái dưới | Di chuyển; đẩy xa lên trên để khóa chạy nếu bật tùy chọn |
| Cần phải dưới | Giữ bắn; kéo ngón để vừa bắn vừa xoay nhìn |
| Vùng trống bên phải | Kéo để nhìn, không tự bắn |
| Ô súng phải trên | Chạm nạp đạn; băng đầy thì không tiêu hao dự trữ |
| NGẮM | Mở/đóng ống ngắm |
| CÚI / NHẢY giữa dưới | Đổi tư thế / nhảy |
| CHẠY | Khóa hoặc hủy chạy |
| BẮN bên trái (tùy chọn) | Giữ bắn bằng ngón khác |
| Ⅱ trái trên | Tạm dừng và thiết lập |

Tại **Thiết lập → Nút bấm**, chỉnh cỡ 85–120%, độ rõ, joystick nổi và bắn trái.
**Ngắm & AI** có độ nhạy riêng khi ngắm và ba mức độ khó. **Hình ảnh** có Thấp,
Cân bằng, Cao và bộ đếm FPS. Thử Cân bằng trước, chuyển Thấp nếu máy nóng.
NPC tìm đường, nghe tiếng súng/bước chân gần và bắn khi có tầm nhìn; vật chắn
có va chạm chặn đạn. Cúi giúp hạ camera và giảm độ tản đạn.

## Mã nguồn và GitHub Actions, không cần máy tính

ZIP `OniRoai-source.zip` có thư mục `OniRoai` và workflow
`.github/workflows/android-build.yml`. Không build Android trực tiếp trong Termux.
Nếu chỉ cài chơi thì không cần làm phần này.

Tải ZIP vào Download, mở Termux và chạy:

```bash
termux-setup-storage
pkg install -y git unzip
cd ~/storage/downloads
[ ! -e "$HOME/OniRoai-build-0.5.0" ] || { echo 'Thư mục đích đã có. Giữ nguyên để tránh ghi đè.'; exit 1; }
unzip OniRoai-source.zip -d "$HOME/OniRoai-build-0.5.0"
cd ~/OniRoai-build-0.5.0/OniRoai
```

Để đưa lên một repo **mới**, tạo repository trống `OniRoai` trên GitHub của
`quanminh2089-blip`, không khởi tạo README, rồi chạy:

```bash
cd ~/OniRoai-build-0.5.0/OniRoai
git init -b main
git add .
git diff --cached --quiet || git commit -m "Add OniRoai 0.5.0 painted mobile HUD"
git remote add origin https://github.com/quanminh2089-blip/OniRoai.git
git push -u origin main
```

Nếu đã có repo game riêng, không chạy lệnh tạo remote mới hoặc ghi đè lên
MQUAN-MOD. Kiểm tra `git status` và đồng bộ `git pull --ff-only` trước khi áp
bản nguồn. Không dùng force push hoặc xóa lịch sử.

Workflow dùng Ubuntu 24.04, Java 17, Godot **4.5.1**, Android build-tools
**35.0.1**, target SDK 35, ARM64. Nó import tài nguyên, kiểm tra luật đấu,
điều khiển, NPC và giao diện OniRoai; sau đó xuất/ký APK, xác minh cấu trúc và
chạy lại kiểm tra từ dữ liệu APK. Tải artifact **OniRoai-0.5.0-ARM64** của run
thành công, giải nén và cài APK bên trong. Không cần Android Studio.

## Kiểm tra và giới hạn

Có kiểm tra luật một phát hạ gục/1 đấu 4/chạm 4 điểm, nhiều ngón, vị trí nút
trên 24 cấu hình màn hình/cỡ nút/tai thỏ, nạp đạn qua ô súng, tư thế nâng súng,
đặt lại tư thế đầu ván và NPC tự di chuyển/bắn. Đã render để xem UI, màn hình
tải, nạp đạn, bắn và lòng kính ngắm. APK được xác minh chữ ký, phiên bản và
việc chứa đủ ảnh/model/script. Kết quả cụ thể và mã SHA-256 nằm trong
`VALIDATION-0.5.0.md` trong mã nguồn.

Kiểm tra dữ liệu APK và render chạy trên Linux; chưa đo FPS, nhiệt độ hoặc
chơi trực tiếp trên điện thoại Android 15 của bạn. Bản này nâng cấp giao diện
và góc cầm súng; map 3D vẫn là Thung Lũng — Trạm 04 của bản 0.4.0.
