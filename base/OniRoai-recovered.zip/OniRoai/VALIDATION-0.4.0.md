# Validation — Tiền Đồn 0.4.0 / Android build 9

Date: 2026-11-03. Built locally with official Godot 4.5.1 Android release template,
Java 17 and Android build-tools 35.0.1. This is not a claim of a GitHub Actions run.

- Source behavior tests: 41 round checks, 31 mobile checks, 6 autonomous-bot checks, all passed.
- Compiled resources extracted from the final APK: the same 41 round, 31 mobile
  and 6 bot checks passed. No script/runtime errors in those test logs.
- Bot combat used autonomous perception, A* movement and physical bullet rays,
  not direct calls to the player-damage function. All four bots moved >3 m,
  an NPC fired, and the stationary player lost the round with score 0–1.
- Cover test used a real StaticBody3D: a wall blocked the NPC ray; removing it
  allowed the same muzzle-to-player ray to hit and immediately end the round.
- Mobile layout checks cover 24 viewport/control-size/notch combinations.
- Actual APK resources were rendered under Mesa llvmpipe at 1536×691. The preview
  uses a staged nearby NPC to inspect the gun and HUD. It is not an Android screenshot.
  Mesa converts ETC2 textures for this desktop QA run; no Android FPS is inferred.
- Signature schemes v2/v3 verified. Certificate SHA-256:
  `809f42e6efeed521a69f13e257d3d827971a64f83b531494b75ece715e7ec802`.
- Package `vn.minhquan.tiendon`, versionName `0.4.0`, versionCode `9`,
  min SDK 24, target SDK 35, native code ARM64 only. No requested permissions.
- APK structure verifier confirms scripts, MP5, soldier, optics, new trees/rocks/
  ferns, sounds and licenses are embedded. No external/nested content pack.
- Android 15 installation, thermal behavior, real-device FPS and input feel have
  not been measured here. These remain phone acceptance checks.

APK SHA-256: `3643bc380a1d2a1820299882b3d96045464399ad4c29c7027250236ebf89034b`
APK bytes: 91990791

## Reproduce on GitHub Actions

Use `.github/workflows/android-build.yml`. It imports assets, executes the three
source suites, exports/signs, verifies the APK and repeats round/mobile tests
against the compiled resources. It uploads the APK and logs. The source ZIP has
no machine-local custom-template paths, SDKs or generated caches.
