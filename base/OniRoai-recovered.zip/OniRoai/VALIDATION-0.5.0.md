# OniRoai 0.5.0 — validation record

Validated 2026-11-03. Android APK built locally with official Godot 4.5.1,
Java 17 and Android build-tools 35.0.1. No GitHub Actions run is claimed here.

## Android artifact

- Filename: `OniRoai-0.5.0.apk`
- APK SHA-256: `506df538f95adeb090477997a2411e3cfd0b7a087937697b4c1abc9c7832fabd`
- Size: 101568914 bytes
- Application label: `OniRoai`
- Package: `vn.minhquan.tiendon` (kept for updating the existing installation)
- Version name: `0.5.0`; version code: `10`
- Minimum SDK: 24; target SDK: 35; native ABI: ARM64 only
- No requested Android permissions, including no Internet permission
- APK signature v2 and v3 verified
- Signing certificate SHA-256:
  `809f42e6efeed521a69f13e257d3d827971a64f83b531494b75ece715e7ec802`

The structure verifier found the original game models, new raster controls,
score/ammo frames, MP5 card picture, avatar, loading art, flash/smoke atlas,
open-scope shader and all gameplay scripts in the final APK. Android launcher
icons were packed from the new avatar; the adaptive foreground has nonempty
alpha bounds `(50, 50, 382, 382)` in its 432px canvas.

## Behavior checks

The compiled resources extracted from this exact APK passed:

- 41 round/gameplay checks: fixed 1v4 roster, one-hit elimination, one point
  per completed round, both first-to-4 match outcomes, pause, replay, real
  player/NPC bullets, real wall occlusion and ammunition transfer.
- 31 mobile-control checks: 24 layout combinations, touch ownership, camera
  gestures without accidental fire, analog movement, sprint, crouch collision,
  overhead clearance, recoil and persistent settings.
- 15 OniRoai checks: card safe areas/overlap across 24 layouts, no separate
  reload button, real card-triggered reload, full-magazine guard, raster art,
  fire-raise pose, short sprite muzzle flash, visible open ADS and a neutral
  gun/cap pose at the next-round countdown.

These total 87 packaged-resource checks, all passing. Source round/mobile/UI
checks passed as well. The six existing autonomous-AI checks passed on source:
all four bots left spawn, navigated the map, perceived/fired at the stationary
player and won a round. Core NPC decision/damage logic is unchanged by this UI
update.

## Visual checks

Actual compiled APK resources were rendered in Godot Compatibility using Mesa
llvmpipe at 1536×691. Inspected the loading scene, menu, live HUD, fire pose,
open scope, reload and settings. `ONIROAI_RENDER_COMPLETE` was reported with
no script or shader errors. Mesa converted unsupported ETC2 textures for this
desktop render; its speed does not measure Android performance.

The nearby NPC, 54% loading state and action poses in the preview fixtures are
staged for visual inspection. Gameplay previews are engine renders from APK
resources; they are not phone screenshots. Loading illustration and avatar are
generated artwork. Full prompt provenance is in `assets/oniroai/prompts.json`.

Android 15 installation, real-device FPS, thermal behavior and subjective
control feel remain phone acceptance checks. The 3D world is still the 0.4.0
Thung Lũng / Trạm 04 map; the higher-detail loading illustration is key art.
