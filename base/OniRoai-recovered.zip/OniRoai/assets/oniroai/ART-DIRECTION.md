# OniRoai 0.5.0 — painted game UI

The controls, score/weapon frames, gun-card picture, avatar, loading illustration,
and small flash/smoke sprites were generated with the built-in image generator
for this original project on 2026-11-03. They are actual PNG raster assets.
There are no external downloads at runtime.

`controls.png` and `frames.png` retain their original transparent alpha.
`oniroai_art.gd` selects AtlasTexture regions, without repainting these images.
Numeric labels, score, ammo and touch behavior are live game data. Press/release,
thumb travel, score pulse, ammunition kick, loading fade/parallax and the reload
strip are runtime animations of the painted textures.

`avatar.png` is the launcher icon source. `tools/make_icons.gd` only resizes and
packs it for Android; it does not draw a replacement logo. `loading.png` is key
art for the loading screen, not a claim of the gameplay's graphical fidelity.
`fx.png` supplies small transparent photographic muzzle flashes and smoke.

The original MP5 A5, soldier and optics model credits remain in
`assets/licenses/TACTICAL-SOURCES.md`. The optical-bore shader opens an opaque
disk in the imported optic; it removes no part of the world image and uses no
black scope vignette. The full world camera zooms to 48 degrees during ADS.

The complete image prompt set is in `prompts.json` beside this file.
